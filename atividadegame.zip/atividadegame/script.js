// script.js
console.log("JS CARREGOU!");
console.log("Testando");

(function () {
  const form = document.getElementById('quizForm');
  const resultArea = document.getElementById('resultArea');
  const resetBtn = document.getElementById('resetBtn');

  if (!form || !resultArea) {
    console.error('Elementos principais não encontrados (quizForm / resultArea).');
    return;
  }

  function showResult(html) {
    resultArea.classList.remove('hidden');
    resultArea.innerHTML = html;
  }

  function hideResult() {
    resultArea.classList.add('hidden');
    resultArea.innerHTML = '';
  }

  function resetForm() {
    form.reset();
    const r = document.getElementById('q7');
    if (r) r.value = 5;
    hideResult();
  }

  resetBtn.addEventListener('click', resetForm);

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const q1 = form.q1?.value;
    const q2 = document.getElementById('q2')?.value;
    const q3 = form.q3?.value;
    const q4 = form.q4?.value;
    const q5 = document.getElementById('q5')?.value;
    const q7 = Number(document.getElementById('q7')?.value || 5);

    if (!q1 || !q2 || !q3 || !q4 || !q5) {
      showResult('<div class="alert alert-danger">Por favor responda todas as perguntas obrigatórias.</div>');
      return;
    }

    let score = 0;
    score += Number(q1);
    score += Number(q2);
    score += Number(q3);
    score += Number(q4);
    score += Number(q5);

    ['h1','h2','h3'].forEach(id => {
      const el = document.getElementById(id);
      if (el && el.checked) score += 1;
    });

    const q7points = Math.round(((q7 - 1) / 9) * 4);
    score += q7points;

    let nivel = '';
    let cor = '';
    if (score >= 16) {
      nivel = 'Estilo de Vida Excelente';
      cor = 'success';
    } else if (score >= 11) {
      nivel = 'Estilo de Vida Moderado';
      cor = 'info';
    } else {
      nivel = 'Precisa de Melhoria';
      cor = 'warning';
    }

    const html = `
      <div class="card p-3 border-${cor}">
        <h3 class="h5 mb-2">Resultado: <span class="badge bg-${cor}">${nivel}</span></h3>
        <p class="mb-1">Pontuação total: <strong>${score}</strong></p>
        <p class="small text-muted mb-0">(${q7points} pontos derivados do nível de energia)</p>
      </div>
    `;

    showResult(html);
  });

})();
